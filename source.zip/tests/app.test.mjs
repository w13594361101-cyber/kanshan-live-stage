import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";

const required = [
  "index.html",
  "src/main.js",
  "src/defaults.js",
  "src/store.js",
  "src/model.js",
  "public/config/activity.json",
  "public/assets/liukanshan-three-quarter-v2.png",
  "public/assets/brand/pujiang-forum-logo-white.png",
  "public/assets/brand/zhihu-logo-white.png"
];

for (const path of required) {
  const info = await stat(path);
  assert.ok(info.size > 0, `${path} should not be empty`);
}

const config = JSON.parse(await readFile("public/config/activity.json", "utf8"));
assert.equal(config.questions.length, 5, "exactly five question slots are required");
assert.equal(config.speakers.length, 5, "exactly five speaker slots are required");
assert.equal(config.experts.length, 5, "exactly five expert slots are required");

const main = await readFile("src/main.js", "utf8");
for (const phase of ["drawingQuestion", "drawingSpeaker", "drawingExpert", "commenting", "complete"]) {
  assert.ok(main.includes(phase), `main flow should include ${phase}`);
}

const css = await readFile("src/styles.css", "utf8");
assert.ok(!css.includes("fonts.googleapis.com"), "production page should not depend on remote fonts");
assert.ok(css.includes("#056de8"), "event background should use the approved blue");
assert.ok(main.includes("brand-lockup"), "event header should use the official joint logo lockup");
assert.ok(main.includes("pujiang-forum-logo-white.png"), "event header should include the reverse forum logo");
assert.ok(main.includes("zhihu-logo-white.png"), "event header should include the supplied reverse Zhihu logo");
assert.ok(main.includes("brand-divider"), "joint logo lockup should use a quiet divider");

const inlineBuilder = await readFile("work/inline_build.mjs", "utf8");
assert.ok(inlineBuilder.includes("escapedAssetPath"), "standalone build should inline BASE-prefixed brand assets");

const modelCode = await readFile("src/model.js", "utf8");
assert.ok(modelCode.includes("liukanshan-three-quarter-v2.png"), "character should use the approved image-two pose");
for (const motion of ["kanshan-breathe", "kanshan-search", "kanshan-listen", "kanshan-celebrate"]) {
  assert.ok(css.includes(motion), `animated character should include ${motion}`);
}
assert.ok(!modelCode.includes('from "three"'), "character display should not distort the approved pose through 3D rotation");
assert.ok(!modelCode.includes("createScarf"), "the classic Kanshan model should not include a scarf");

const defaultsCode = await readFile("src/defaults.js", "utf8");
assert.ok(defaultsCode.includes("浦江创新论坛 × 知乎"), "stage brand should show the joint event name");
assert.ok(defaultsCode.includes("Y-Hubs 青年科学家"), "stage brand should show the Y-Hubs subtitle");

const storeCode = await readFile("src/store.js", "utf8");
assert.ok(storeCode.includes("Hi～我是刘看山"), "opening copy should introduce Liu Kanshan");

const model = await stat("public/assets/liukanshan-three-quarter-v2.png");
assert.ok(model.size < 5 * 1024 * 1024, "character sprite should stay below 5 MB");

console.log("All product checks passed.");
