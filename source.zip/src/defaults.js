export const defaults = {
  eventName: "Y-Hubs 青年科学家",
  productName: "浦江创新论坛 × 知乎",
  questions: Array.from({ length: 5 }, (_, index) => ({
    id: `q${index + 1}`,
    text: `问题占位 0${index + 1}｜请在控制台填写正式问题`,
    tag: `问题${["一", "二", "三", "四", "五"][index]}`,
    enabled: true
  })),
  speakers: Array.from({ length: 5 }, (_, index) => ({
    id: `s${index + 1}`,
    name: `分享嘉宾 0${index + 1}`,
    title: "身份信息待补充",
    available: true
  })),
  experts: Array.from({ length: 5 }, (_, index) => ({
    id: `e${index + 1}`,
    name: `点评专家 0${index + 1}`,
    title: "身份信息待补充",
    available: true
  }))
};
