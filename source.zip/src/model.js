import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

export function mountKanshan(container) {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(28, 1, 0.1, 100);
  camera.position.set(0, 0.15, 7.2);

  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x8c7c68, 3.1));
  const key = new THREE.DirectionalLight(0xffffff, 4.2);
  key.position.set(-3, 5, 5);
  key.castShadow = true;
  scene.add(key);
  const rim = new THREE.DirectionalLight(0xff5b5b, 2.2);
  rim.position.set(4, 2, -4);
  scene.add(rim);

  const group = new THREE.Group();
  scene.add(group);
  let modelRoot = null;
  let nose = null;

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(1.05, 64),
    new THREE.MeshBasicMaterial({ color: 0x201e1a, transparent: true, opacity: 0.12, depthWrite: false })
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = -1.34;
  shadow.scale.y = 0.32;
  scene.add(shadow);

  const fallback = document.createElement("img");
  fallback.src = `${import.meta.env.BASE_URL}assets/liukanshan-turnaround.png`;
  fallback.alt = "刘看山基础造型";
  fallback.className = "model-fallback";
  container.appendChild(fallback);

  new GLTFLoader().load(
    `${import.meta.env.BASE_URL}assets/liukanshan.glb`,
    (gltf) => {
      const model = gltf.scene;
      model.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
          child.material.roughness = 0.82;
          child.material.metalness = 0;
        }
      });
      model.rotation.y = 0;
      modelRoot = model;
      group.add(model);

      const face = createFaceDetails();
      nose = face.userData.nose;
      group.add(face);
      fallback.classList.add("is-hidden");
      container.dataset.ready = "true";
    },
    undefined,
    () => container.dataset.failed = "true"
  );

  let phase = "idle";
  let start = performance.now();

  function resize() {
    const { clientWidth, clientHeight } = container;
    renderer.setSize(clientWidth, clientHeight, false);
    camera.aspect = clientWidth / Math.max(clientHeight, 1);
    camera.updateProjectionMatrix();
  }

  const observer = new ResizeObserver(resize);
  observer.observe(container);
  resize();

  function animate(now) {
    const t = (now - start) / 1000;
    const active = phase.startsWith("drawing");
    const listening = phase === "speaking" || phase === "commenting";
    const celebrating = phase === "complete" || phase === "finished";
    const reveal = ["question", "speaker", "expert"].includes(phase);
    const breathing = 1 + Math.sin(t * 2.2) * 0.012;
    const jump = celebrating ? Math.abs(Math.sin(t * 3.8)) * 0.18 : 0;
    group.position.y = jump + Math.sin(t * (active ? 7 : 2.1)) * (active ? 0.07 : 0.024);
    group.rotation.y = active ? Math.sin(t * 5.2) * 0.2 : Math.sin(t * 0.72) * 0.035;
    group.rotation.z = listening ? -0.045 + Math.sin(t * 1.4) * 0.014 : Math.sin(t * (reveal ? 3 : 1.25)) * (reveal ? 0.026 : 0.012);
    group.scale.set(1, breathing, 1);
    if (modelRoot) modelRoot.position.y = active ? Math.sin(t * 8) * 0.025 : 0;
    if (nose) nose.scale.y = 0.82 * (Math.sin(t * 0.9) > 0.985 ? 0.92 : 1);
    shadow.material.opacity = active ? 0.08 : 0.12;
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);

  return {
    setPhase(next) {
      if (next !== phase) start = performance.now();
      phase = next;
      container.dataset.phase = next;
    }
  };
}

function createFaceDetails() {
  const group = new THREE.Group();
  const black = new THREE.MeshStandardMaterial({ color: 0x17191f, roughness: 0.72 });
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.16, 28, 20), black);
  nose.position.set(0, 0.66, 1.39);
  nose.scale.set(1.08, 0.82, 0.55);
  nose.castShadow = true;
  group.add(nose);

  const eyebrowGeometry = new THREE.CapsuleGeometry(0.022, 0.13, 5, 10);
  [-0.31, 0.31].forEach((x) => {
    const eyebrow = new THREE.Mesh(eyebrowGeometry, black);
    eyebrow.position.set(x, 0.8, 1.03);
    eyebrow.rotation.z = Math.PI / 2;
    eyebrow.rotation.x = Math.PI / 2;
    group.add(eyebrow);
  });
  group.userData.nose = nose;
  return group;
}
