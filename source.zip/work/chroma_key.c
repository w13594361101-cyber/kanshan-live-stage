#include <CoreFoundation/CoreFoundation.h>
#include <CoreGraphics/CoreGraphics.h>
#include <ImageIO/ImageIO.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static double clamp(double value, double low, double high) {
  return fmin(high, fmax(low, value));
}

int main(int argc, const char **argv) {
  if (argc != 3) {
    fprintf(stderr, "usage: chroma_key input.jpg output.png\n");
    return 2;
  }

  CFURLRef inputURL = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 *)argv[1], strlen(argv[1]), false);
  CGImageSourceRef source = CGImageSourceCreateWithURL(inputURL, NULL);
  CGImageRef image = source ? CGImageSourceCreateImageAtIndex(source, 0, NULL) : NULL;
  if (!image) return 3;

  size_t width = CGImageGetWidth(image);
  size_t height = CGImageGetHeight(image);
  size_t rowBytes = width * 4;
  UInt8 *pixels = calloc(height, rowBytes);
  CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
  CGBitmapInfo bitmapInfo = kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big;
  CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, rowBytes, colorSpace, bitmapInfo);
  CGContextDrawImage(context, CGRectMake(0, 0, width, height), image);

  const double backgroundBlue = 14.0;
  for (size_t offset = 0; offset < height * rowBytes; offset += 4) {
    double red = pixels[offset];
    double green = pixels[offset + 1];
    double blue = pixels[offset + 2];
    double dominance = green - fmax(red, blue);
    // Non-green pixels are fully opaque. Only the antialiased transition from
    // the figure into the highly saturated screen green receives soft alpha.
    double alpha = dominance <= 25 ? 1.0 : (240.0 - dominance) / 215.0;
    alpha = clamp(alpha, 0, 1);

    if (alpha < 0.12) {
      pixels[offset] = pixels[offset + 1] = pixels[offset + 2] = pixels[offset + 3] = 0;
      continue;
    }

    double foregroundRed = clamp(red / alpha, 0, 255);
    double foregroundGreen = clamp((green - (1 - alpha) * 255) / alpha, 0, 255);
    double foregroundBlue = clamp((blue - (1 - alpha) * backgroundBlue) / alpha, 0, 255);
    pixels[offset] = (UInt8)(foregroundRed * alpha);
    pixels[offset + 1] = (UInt8)(foregroundGreen * alpha);
    pixels[offset + 2] = (UInt8)(foregroundBlue * alpha);
    pixels[offset + 3] = (UInt8)(alpha * 255);
  }

  size_t minX = width, minY = height, maxX = 0, maxY = 0;
  for (size_t y = 0; y < height; y++) {
    for (size_t x = 0; x < width; x++) {
      if (pixels[y * rowBytes + x * 4 + 3] > 30) {
        minX = x < minX ? x : minX;
        minY = y < minY ? y : minY;
        maxX = x > maxX ? x : maxX;
        maxY = y > maxY ? y : maxY;
      }
    }
  }

  size_t padding = 28;
  minX = minX > padding ? minX - padding : 0;
  minY = minY > padding ? minY - padding : 0;
  maxX = maxX + padding < width ? maxX + padding : width - 1;
  maxY = maxY + padding < height ? maxY + padding : height - 1;

  CGImageRef fullImage = CGBitmapContextCreateImage(context);
  CGImageRef outputImage = CGImageCreateWithImageInRect(
    fullImage,
    CGRectMake(minX, minY, maxX - minX + 1, maxY - minY + 1)
  );
  CFURLRef outputURL = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 *)argv[2], strlen(argv[2]), false);
  CGImageDestinationRef destination = CGImageDestinationCreateWithURL(outputURL, CFSTR("public.png"), 1, NULL);
  CGImageDestinationAddImage(destination, outputImage, NULL);
  bool wrote = CGImageDestinationFinalize(destination);

  CFRelease(destination);
  CFRelease(outputURL);
  CGImageRelease(outputImage);
  CGImageRelease(fullImage);
  CGContextRelease(context);
  CGColorSpaceRelease(colorSpace);
  free(pixels);
  CGImageRelease(image);
  CFRelease(source);
  CFRelease(inputURL);
  return wrote ? 0 : 4;
}
