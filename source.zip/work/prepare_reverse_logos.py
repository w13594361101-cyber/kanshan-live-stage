from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
BRAND = ROOT / "public" / "assets" / "brand"


def forum_reverse() -> Image.Image:
    source = Image.open(BRAND / "pujiang-forum-logo-color.png").convert("RGB")
    alpha = Image.new("L", source.size)
    alpha.putdata([
        max(0, min(255, (255 - min(pixel)) * 4))
        for pixel in source.getdata()
    ])
    result = Image.new("RGBA", source.size, (255, 255, 255, 0))
    result.putalpha(alpha)
    box = alpha.getbbox()
    return result.crop(box) if box else result


def trim_alpha(image: Image.Image) -> Image.Image:
    image = image.convert("RGBA")
    alpha = image.getchannel("A")
    box = alpha.getbbox()
    return image.crop(box) if box else image


forum = forum_reverse()
zhihu = trim_alpha(Image.open("/Users/zhihu/Downloads/Logo/反白稿.png"))
forum.save(BRAND / "pujiang-forum-logo-white.png", optimize=True)
zhihu.save(BRAND / "zhihu-logo-white.png", optimize=True)

preview = Image.new("RGBA", (1200, 360), (5, 109, 232, 255))

forum_height = 142
forum_scaled = forum.resize(
    (round(forum.width * forum_height / forum.height), forum_height),
    Image.Resampling.LANCZOS,
)
zhihu_height = 92
zhihu_scaled = zhihu.resize(
    (round(zhihu.width * zhihu_height / zhihu.height), zhihu_height),
    Image.Resampling.LANCZOS,
)

x = 76
y = 70
preview.alpha_composite(forum_scaled, (x, y))
x += forum_scaled.width + 42
preview.alpha_composite(Image.new("RGBA", (2, 120), (255, 255, 255, 95)), (x, y + 10))
x += 44
preview.alpha_composite(zhihu_scaled, (x, y + 24))
preview.save(ROOT / "work" / "reverse-logo-preview.png", optimize=True)
